using System.Collections;
using System.Collections.Generic;

public static class GameParameters
{
    // Player
    public static float PlayerMoveAmount = 0.025f;

    // Bullet
    public static float BulletSpeed = 20f;

    // Scenes
    public static string GameOverSceneName = "GameOverScreen";
    public static string HubRoomSceneName = "MainHub";
}
