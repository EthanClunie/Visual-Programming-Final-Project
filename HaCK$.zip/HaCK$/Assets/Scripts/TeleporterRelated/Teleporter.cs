using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Teleporter : MonoBehaviour
{
    public string sRoomToLoad;
    private bool canTeleport = true;

    private void OnTriggerEnter(Collider other)
    {
        if ((other.gameObject.tag == "Player") && canTeleport)
        {
            SceneHandler.Instance.LoadRoom(sRoomToLoad);
        }
    }

    public void LockPortal()
    {
        canTeleport = false;
    }

    public void UnlockPortal()
    {
        canTeleport = true;
    }

}
