using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss : MonoBehaviour
{
    public static Boss Instance;
    public Transform player;
    public bool isFlipped = false;

    public float bossHealth;
    private bool hasDied = false;

    private bool hasTakenPuzzleDmg = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            Instance = this;
        }

        bossHealth = GameParameters.BossMaxHealth;
    }

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        OnLoad();
    }

    private void Update()
    {
        if (IsDead() && !hasDied)
        {
            OnDeath();
            Game.Instance.RoomCompleted();
            hasDied = true;
        }
    }

    private void OnLevelWasLoaded(int level)
    {
        int currSceneNum = SceneHandler.Instance.GetCurrentSceneNumber();
        if ((currSceneNum == level) && !hasTakenPuzzleDmg)
        {
            OnLoad();
            hasTakenPuzzleDmg = true;
        }
    }

    public void LookAtPlayer()
    {
        Vector3 flipped = transform.localScale;
        flipped.z *= -1f;

        if (transform.position.x > player.position.x && isFlipped)
        {
            transform.localScale = flipped;
            transform.Rotate(0f, 180f, 0f);
            isFlipped = false;
        }

        else if (transform.position.x < player.position.x && !isFlipped)
        {
            transform.localScale = flipped;
            transform.Rotate(0f, 180f, 0f);
            isFlipped = true;
        }
    }

    public void OnHit()
    {
        if (Game.Instance.HasRoomBeenCleared(1))
        {
            TakeDamage(GameParameters.BulletUpgradedDmg);
        }
        else
        {
            TakeDamage(GameParameters.BulletBaseDmg);
        }
        
    }

    private void OnLoad()
    {
        int numRoomsComplete = Game.Instance.GetNumRoomsCompleted();

        TakeDamage(GameParameters.DmgToBossOnPuzzleCompletion * numRoomsComplete);
    }

    private bool IsDead()
    {
        if (bossHealth <= 0f)
        {
            return true;
        }

        return false;
    }

    private void TakeDamage(float dmgAmount)
    {
        bossHealth -= dmgAmount;
    }

    private void OnDeath()
    {
        print("Dead");
    }

}
