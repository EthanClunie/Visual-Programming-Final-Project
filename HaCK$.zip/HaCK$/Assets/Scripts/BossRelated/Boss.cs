using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss : MonoBehaviour
{
    public static Boss Instance;
    public Transform player;
    public bool isFlipped = false;

    private float bossHealth;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            Instance = this;
        }

        bossHealth = GameParameters.BossMaxHealth;
    }

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    private void Update()
    {
        if (IsDead())
        {
            Game.Instance.RoomCompleted();
        }
    }

    private void OnLevelWasLoaded(int level)
    {
        int numRoomsComplete = Game.Instance.GetNumRoomsCompleted();

        print("Health = " + bossHealth);
        TakeDamage(GameParameters.DmgToBossOnPuzzleCompletion * numRoomsComplete);
        print("Health = " + bossHealth);
    }

    public void LookAtPlayer()
    {
        Vector3 flipped = transform.localScale;
        flipped.z *= -1f;

        if (transform.position.x > player.position.x && isFlipped)
        {
            transform.localScale = flipped;
            transform.Rotate(0f, 180f, 0f);
            isFlipped = false;
        }

        else if (transform.position.x < player.position.x && !isFlipped)
        {
            transform.localScale = flipped;
            transform.Rotate(0f, 180f, 0f);
            isFlipped = true;
        }
    }

    public void OnHit()
    {
        TakeDamage(GameParameters.BulletDamage);
    }

    private void TakeDamage(float dmgAmount)
    {
        print("Ouch");
    }

    private bool IsDead()
    {
        if (bossHealth <= 0f)
        {
            return true;
        }

        return false;
    }

}
