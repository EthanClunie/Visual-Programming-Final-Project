using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public Animator animator;
    public float Speed = 0;

    private SpriteRenderer PlayerSpriteRenderer;
    private GameObject[] players;

    private short playerHealth = 100;

    private void Start()
    {
        PlayerSpriteRenderer = gameObject.GetComponent<SpriteRenderer>();

        DontDestroyOnLoad(gameObject);
    }

    public bool IsPlayerDead()
    {
        return (playerHealth <= 0);
    }

    public void MoveManually(Vector2 direction)
    {
        Move(direction);
    }

    private void OnLevelWasLoaded(int level)
    {
        FindStartPos();

        DestroyExtraPlayers();
    }

    private void FindStartPos()
    {
        transform.position = GameObject.FindWithTag("StartPos").transform.position;
    }

    private void DestroyExtraPlayers()
    {
        players = GameObject.FindGameObjectsWithTag("Player");
        if (players.Length > 1)
        {
            Destroy(players[1]);
        }
    }

    private void Move(Vector2 direction)
    {
        FaceCorrectDirection(direction);
        PlayerSpriteRenderer.transform.Translate(CalculateAmountToMove(direction));
        KeepOnScreen();
    }

    private Vector3 CalculateAmountToMove(Vector2 direction)
    {
        float amountX = direction.x * GameParameters.PlayerMoveAmount;
        float amountY = direction.y * GameParameters.PlayerMoveAmount;


        return new Vector3(amountX, amountY, 0);
    }

    private void FaceCorrectDirection(Vector2 direction)
    {
        if (direction.x == 1) // face right
        {
            PlayerSpriteRenderer.flipX = false;
        }
        else if (direction.x == -1) // face left
        {
            PlayerSpriteRenderer.flipX = true;
        }
    }

    private void KeepOnScreen()
    {
        PlayerSpriteRenderer.transform.position = SpriteTools.ConstrainToScreen(PlayerSpriteRenderer);
    }
}
