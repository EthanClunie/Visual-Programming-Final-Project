using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public static Player Instance;
    public Animator animator;
    public GameObject BulletFirePoint;

    private SpriteRenderer BulletSpriteRenderer;
    private GameObject[] players;

    private short playerHealth = 100;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            Instance = this;
        }

    }

    private void Start()
    {
        BulletSpriteRenderer = BulletFirePoint.GetComponent<SpriteRenderer>();

        DontDestroyOnLoad(gameObject);
    }

    public bool IsPlayerDead()
    {
        return (playerHealth <= 0);
    }

    public void CorrectAimDirection(Vector2 direction)
    {
        CorrectFirePosition(direction);
    }

    private void OnLevelWasLoaded(int level)
    {
        FindStartPos();

        DestroyExtraPlayers();
    }

    private void DestroyExtraPlayers()
    {
        players = GameObject.FindGameObjectsWithTag("Player");
        if (players.Length > 1)
        {
            Destroy(players[1]);
        }
    }

    private void FindStartPos()
    {
        transform.position = GameObject.FindWithTag("StartPos").transform.position;
    }

    private void CorrectFirePosition(Vector2 direction)
    {
        if (direction.x == 1) // face right
        {
            BulletSpriteRenderer.gameObject.transform.position = GameObject.FindWithTag("FirePointRightPos").transform.position;
            BulletSpriteRenderer.flipX = false;
        }
        else if (direction.x == -1) // face left
        {
            BulletSpriteRenderer.gameObject.transform.position = GameObject.FindWithTag("FirePointLeftPos").transform.position;
            BulletSpriteRenderer.flipX = true;
        }
    }

}
