using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public Rigidbody BulletRigidBody;
    public Animator animator;

    void Start()
    {
        BulletRigidBody.velocity = transform.right * GameParameters.BulletSpeed;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Boss")
        {
            Boss.Instance.OnHit();

            animator.SetTrigger("BulletBurst");
        }
        else if (other.gameObject.tag == "Enemy")
        {
            // Enemy takes dmg

            // Play bullet burst animation
            
        }

        Destroy(this.gameObject);
    }

    void OnBecameInvisible()
    {
        Destroy(this.gameObject);
    }
}
