using System.Collections;
using System.Collections.Generic;

public static class GameParameters
{
    // Game
    public static int TargetFrameRate = 60;

    // Camera
    public static float ScreenShakeDuration = 1.0f;
    public static float ScreenShakeMagnitude = 0.3f;

    // Scenes
    public static string GameOverSceneName = "GameOverScreen";
    public static string HubRoomSceneName = "MainHub";

    // Player
    public static float PlayerMaxHealth = 50f;
    public static float PlayerMoveAmount = 0.085f;
    public static float SprintMoveIncrease = 0.0425f;

    // Boss
    public static float BossMaxHealth = 500f;

    // Enemy
    public static float EnemyMaxHealth = 50f;

    // Bullet
    public static float BulletSpeed = 20f;
    public static float BulletBaseDmg = 10f;
    public static float BulletUpgradedDmg = 20f;

    // Puzzles
    public static float DmgToBossOnPuzzleCompletion = 25f;

    public static float MinDiffForBlockPuzzle = 0.1f;

    public static float WaitTimeForNextKeyKonamiCode = 0.5f;
    public static float TimeDisplayKonamiSuccess = 5f;
}
