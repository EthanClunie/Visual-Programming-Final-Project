using UnityEngine;
using System.Collections;

public class CameraShake : MonoBehaviour
{
	public Transform camTransform;

	private GameObject[] shakers;

	void Start()
	{
		if (camTransform == null)
		{
			camTransform = GetComponent(typeof(Transform)) as Transform;
		}

		DontDestroyOnLoad(this.gameObject);
	}

    private void OnLevelWasLoaded(int level)
	{
		camTransform = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Transform>();

		DestroyExtraShakers();
    }

	private void DestroyExtraShakers()
	{
		shakers = GameObject.FindGameObjectsWithTag("Shaker");
		if (shakers.Length > 1)
		{
			Destroy(shakers[1]);
		}
	}

	public IEnumerator ScreenShake(float duration, float magnitude)
    {
		Vector3 originalPos = camTransform.localPosition;

		float elapsedTime = 0.0f;

		while (elapsedTime < duration)
        {
			float x = Random.Range(-1f, 1f) * magnitude;
			float y = Random.Range(-1f, 1f) * magnitude;

			transform.localPosition = new Vector3(x, y, originalPos.z);

			elapsedTime += Time.deltaTime;

			yield return null;
		}

		transform.localPosition = originalPos;
	}

}
