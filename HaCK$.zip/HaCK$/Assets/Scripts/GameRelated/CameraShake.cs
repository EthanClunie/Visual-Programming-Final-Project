using UnityEngine;
using System.Collections;

public class CameraShake : MonoBehaviour
{
	// Transform of the camera to shake. Grabs the gameObject's transform
	// if null.
	public Transform camTransform;

	// How long the object should shake for.
	public float shakeDuration;

	// Amplitude of the shake. A larger value shakes the camera harder.
	public float shakeAmount = 0.15f;
	public float decreaseFactor = 1.0f;

	private GameObject[] shakers;

	Vector3 originalPos;

	void Awake()
	{
		if (camTransform == null)
		{
			camTransform = GetComponent(typeof(Transform)) as Transform;
		}

		shakeDuration = GameParameters.ScreenShakeDuration;
		DontDestroyOnLoad(this.gameObject);
	}

    private void OnLevelWasLoaded(int level)
	{
		camTransform = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Transform>();

		DestroyExtraShakers();
    }

	private void DestroyExtraShakers()
	{
		shakers = GameObject.FindGameObjectsWithTag("Shaker");
		if (shakers.Length > 1)
		{
			Destroy(shakers[1]);
		}
	}

	void OnEnable()
	{
		originalPos = camTransform.localPosition;
	}

	public IEnumerator ScreenShake(float duration, float magnitude)
    {
		Vector3 originalPos = camTransform.localPosition;

		float elapsedTime = 0.0f;

		while (elapsedTime < duration)
        {
			float x = Random.Range(-1f, 1f) * magnitude;
			float y = Random.Range(-1f, 1f) * magnitude;

			transform.localPosition = new Vector3(x, y, originalPos.z);

			elapsedTime += Time.deltaTime;

			yield return null;
		}

		transform.localPosition = originalPos;

	}

	void Update()
	{
		if (shakeDuration > 0)
		{
			camTransform.localPosition = originalPos + Random.insideUnitSphere * shakeAmount;

			shakeDuration -= Time.deltaTime * decreaseFactor;
		}
		else
		{
			shakeDuration = 0f;
			camTransform.localPosition = originalPos;
		}
	}
}
