using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour
{
    public static Game Instance;
    public Player Player;
    public Teleporter Teleporter;
    public CameraShake CameraShaker;

    private bool isGamePaused = false;

    private short numRoomsCompleted;
    private string lastRoomCompleted;
    private bool isR1Cleared = false;
    private bool isR2Cleared = false;
    private bool isR3Cleared = false;
    private bool isR4Cleared = false;
    private bool isR5Cleared = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            Instance = this;
        }

        numRoomsCompleted = 0;
        CameraShaker.enabled = false;
        DontDestroyOnLoad(gameObject);
    }

    private void Update()
    {
        if (Player.IsPlayerDead())
        {
            GameOver();
        }
    }

    public void RoomCompleted()
    {
        ++numRoomsCompleted;
        lastRoomCompleted = SceneHandler.Instance.GetCurrentSceneName();
        RewardCompletion();
    }

    public int GetNumRoomsCompleted()
    {
        return numRoomsCompleted;
    }

    public void PauseGame()
    {
        Time.timeScale = 0;
        isGamePaused = true;
        PauseGameState.Instance.DisplayPauseText();
    }

    public void ResumeGame()
    {
        Time.timeScale = 1;
        isGamePaused = false;
        PauseGameState.Instance.HidePauseText();
    }

    public bool IsGamePaused()
    {
        return isGamePaused;
    }

    public void QuitGame()
    {
        UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();
    }

    private void GameWin()
    {
        print("You won");
        print("Rooms cleared: " + numRoomsCompleted);
        DisableGameplay();
    }

    private void GameOver()
    {
        print("You died");
        print("Rooms cleared: " + numRoomsCompleted);
        DisableGameplay();
    }

    private void DisableGameplay()
    {
        ToggleShooting();
        Time.timeScale = 0;
        isGamePaused = true;
    }

    private void RewardCompletion()
    {
        if (lastRoomCompleted == "Room1")         // Maze
        {
            if (!isR1Cleared)
            {
                // Cause camera shake and scream sound
                ScreenShake();

                isR1Cleared = true;
            }
            else
            {
                // Do nothing
            }

        }
        else if ((lastRoomCompleted == "Room2") || (lastRoomCompleted == "TestingScene"))    // Block pushing
        {
            if (!isR2Cleared)
            {
                // Cause camera shake and scream sound
                ScreenShake();

                ToggleShooting();
                isR2Cleared = true;
            }
            else
            {
                // Do nothing
            }
            
        }
        else if (lastRoomCompleted == "Room3")    // Konami Code
        {
            if (!isR3Cleared)
            {
                // Cause camera shake and scream sound
                ScreenShake();

                UnlockSprint();
                isR3Cleared = true;
            }
            else
            {
                // Do nothing
            }

        }
        else if (lastRoomCompleted == "Room4")    // Shooting room
        {
            if (!isR4Cleared)
            {
                // Cause camera shake and scream sound
                ScreenShake();

                // Give hint for Konami code puzzle

                isR4Cleared = true;
            }
            else
            {
                // Do nothing
            }

        }
        else if (lastRoomCompleted == "Room5")    // Boss room
        {
            if (!isR5Cleared)
            {
                GameWin();
                isR5Cleared = true;
            }
            else
            {
                // Do nothing
            }
            
        }
    }

    private void ToggleShooting()
    {
        PlayerWeapon.Instance.ToggleShooting();
    }

    private void UnlockSprint()
    {
        PlayerController2D.Instance.UnlockSprint();
    }

    private void ScreenShake()
    {
        StartCoroutine(CameraShaker.ScreenShake(GameParameters.ScreenShakeDuration, GameParameters.ScreenShakeMagnitude));
    }

    IEnumerator ShakeScreen()
    {
        CameraShaker.enabled = true;
        yield return new WaitForSeconds(GameParameters.ScreenShakeDuration + 1);
        CameraShaker.enabled = false;
    }

}
