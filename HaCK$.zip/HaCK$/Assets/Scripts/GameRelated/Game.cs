using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour
{
    public static Game Instance;
    public Player Player;
    public Teleporter Teleporter;

    private bool isGamePaused = false;
    private bool isMazeSolved = false;
    private bool isShootingRangeSolved = false;
    private bool isBlockPuzzleSolved = false;
    private bool isKonamiSolved = false;
    private short numRoomsCompleted;
    private string lastRoomCompleted;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            Instance = this;
        }
        numRoomsCompleted = 0;
    }

    private void Update()
    {
        if (Player.IsPlayerDead())
        {
            GameOver();
        }
    }

    public void RoomCompleted()
    {
        IncrementNumRoomsCompleted();
        lastRoomCompleted = SceneHandler.Instance.GetCurrentSceneName();
        RewardCompletion();
    }

    public int GetNumRoomsCompleted()
    {
        return numRoomsCompleted;
    }

    public bool IsMazeSolved()
    {
        return isMazeSolved;
    }

    public bool IsShootingRangeSolved()
    {
        return isShootingRangeSolved;
    }

    public bool IsBlockPuzzleSolved()
    {
        return isBlockPuzzleSolved;
    }

    public bool IsKonamiCodeSolved()
    {
        return isKonamiSolved;
    }

    public void PauseGame()
    {
        Time.timeScale = 0;
        isGamePaused = true;
        PauseGameState.Instance.DisplayPauseText();
    }

    public void ResumeGame()
    {
        Time.timeScale = 1;
        isGamePaused = false;
        PauseGameState.Instance.HidePauseText();
    }

    public bool IsGamePaused()
    {
        return isGamePaused;
    }

    public void QuitGame()
    {
        UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();
    }

    private void GameWin()
    {

    }

    private void GameOver()
    {
        // Game over stuff
        print("You died");
    }

    private void RewardCompletion()
    {
        if (lastRoomCompleted == "Room1")         // Maze
        {
            // Cause camera shake and scream sound

            // Just drains boss hp
            isMazeSolved = true;
        }
        else if ((lastRoomCompleted == "Room2") || (lastRoomCompleted == "TestingScene"))    // Block pushing
        {
            // Cause camera shake and scream sound

            UnlockShooting();
            isShootingRangeSolved = true;
        }
        else if (lastRoomCompleted == "Room3")    // Konami Code
        {
            // Cause camera shake and scream sound

            UnlockSprint();
            isBlockPuzzleSolved = true;
        }
        else if (lastRoomCompleted == "Room4")    // Shooting room
        {
            // Cause camera shake and scream sound

            // Give hint for Konami code puzzle

            isKonamiSolved = true;
        }
        else if (lastRoomCompleted == "Room5")    // Boss room
        {
            GameWin();
        }
    }

    private void UnlockShooting()
    {
        PlayerWeapon.Instance.UnlockShooting();
    }

    private void UnlockSprint()
    {
        PlayerController2D.Instance.UnlockSprint();
    }

    private void IncrementNumRoomsCompleted()
    {
        ++numRoomsCompleted;
    }

}
