using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(KonamiCode))]
public class KonamiCodePuzzle : MonoBehaviour
{
    public Text SuccessText;

    private KonamiCode KonamiCode;

    void Start()
    {
        KonamiCode = gameObject.GetComponent<KonamiCode>();
        HideSuccessText();
    }

    void Update()
    {
        if (KonamiCode.success)
        {
            StartCoroutine(DisplaySuccessForTime());    
        }
    }

    IEnumerator DisplaySuccessForTime()
    {
        DisplaySuccessText();
        yield return new WaitForSeconds(GameParameters.TimeDisplayKonamiSuccess);
        HideSuccessText();
    }

    private void DisplaySuccessText()
    {
        SuccessText.gameObject.SetActive(true);
    }

    private void HideSuccessText()
    {
        SuccessText.gameObject.SetActive(false);
        KonamiCode.ResetSuccess();
    }
}
