using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MazeGoal : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            MarkPuzzleAsSolved();
            gameObject.SetActive(false);
        }
    }

    private void MarkPuzzleAsSolved()
    {
        print("Maze solved");
        Game.Instance.RoomCompleted();
    }
}
