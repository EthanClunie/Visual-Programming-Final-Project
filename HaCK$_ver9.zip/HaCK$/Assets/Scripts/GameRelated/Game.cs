using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour
{
    public static Game Instance;
    public Player Player;
    public Teleporter Teleporter;

    private bool isGamePaused = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            Instance = this;
        }
    }

    private void Update()
    {
        if (Player.IsPlayerDead())
        {
            GameOver();
        }
    }

    public void GameOver()
    {
        // Game over stuff
        print("You died");
    }

    public void PauseGame()
    {
        Time.timeScale = 0;
        isGamePaused = true;
        PauseGameState.Instance.DisplayPauseText();
    }

    public void ResumeGame()
    {
        Time.timeScale = 1;
        isGamePaused = false;
        PauseGameState.Instance.HidePauseText();
    }

    public bool IsGamePaused()
    {
        return isGamePaused;
    }

    public void QuitGame()
    {
        UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();
    }

}
