using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyboardInput : MonoBehaviour
{
    public Player Player;
    public Animator animator;

    void Update()
    {
        if (Game.Instance.IsGamePaused())
        {
            // Game Management
            if (Input.GetKeyDown(KeyCode.P))
            {
                Game.Instance.ResumeGame();
            }
        }
        else
        {
            // Game Management
            if (Input.GetKeyDown(KeyCode.P))
            {
                Game.Instance.PauseGame();
            }

            // Movement
            if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
            {
                Player.MoveManually(new Vector2(0, 1));
                animator.SetTrigger("Player_Sprint");
            }
            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
            {
                Player.MoveManually(new Vector2(-1, 0));
                animator.SetTrigger("Player_Sprint");
            }
            if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
            {
                Player.MoveManually(new Vector2(0, -1));
                animator.SetTrigger("Player_Sprint");
            }
            if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
            {
                Player.MoveManually(new Vector2(1, 0));
                animator.SetTrigger("Player_Sprint");
            }

        }

        // Game Exit
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Game.Instance.QuitGame();
        }

    }


}
