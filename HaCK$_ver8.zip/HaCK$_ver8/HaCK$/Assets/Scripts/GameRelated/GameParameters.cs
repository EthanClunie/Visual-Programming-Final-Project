using System.Collections;
using System.Collections.Generic;

public static class GameParameters
{
    // Game
    public static int TargetFrameRate = 60;

    // Scenes
    public static string GameOverSceneName = "GameOverScreen";
    public static string HubRoomSceneName = "MainHub";

    // Player
    public static float PlayerMoveAmount = 0.085f;

    // Bullet
    public static float BulletSpeed = 20f;

    // Puzzles
    public static float MinDiffForBlockPuzzle = 0.1f;

    public static float WaitTimeForNextKeyKonamiCode = 0.5f;
    public static float TimeDisplayKonamiSuccess = 5f;
}
