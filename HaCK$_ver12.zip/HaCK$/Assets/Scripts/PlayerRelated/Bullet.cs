using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public Rigidbody2D BulletRigidBody;

    void Start()
    {
        BulletRigidBody.velocity = transform.right * GameParameters.BulletSpeed;
    }

    void OnBecameInvisible()
    {
        Destroy(this.gameObject);
    }
}
