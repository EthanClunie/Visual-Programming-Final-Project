using System.Collections;
using System.Collections.Generic;

public static class GameParameters
{
    public static float PlayerMoveAmount = 0.02f;
}
